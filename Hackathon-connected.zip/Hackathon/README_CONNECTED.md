# Campus Mind AI — Frontend/Backend Connection

The frontend is now connected to the FastAPI backend for authentication and the student attendance dashboard.

## Backend

1. Copy `backend/.env.example` to `backend/.env` and fill in your MongoDB/Gemini values.
2. From `backend/`, start FastAPI:

```bash
uvicorn app.main:app --reload --port 8000
```

The API will be available at `http://localhost:8000`.

## Frontend

1. Ensure `frontend/campus-mind-ai-authentication/.env.local` contains:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

2. From `frontend/campus-mind-ai-authentication/`:

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## What was connected

- Student/faculty/admin login forms now call `/login/{role}` instead of using mock credentials.
- JWT access tokens are stored with the frontend session and automatically sent as `Authorization: Bearer ...`.
- The backend login response now includes the user's stored name.
- Student dashboard attendance is loaded from the protected `/attendance/` endpoint.
- FastAPI CORS accepts both `localhost:3000` and `127.0.0.1:3000`.

## Important security note

The original uploaded project contained real-looking secrets in `backend/.env`. They were intentionally excluded from the connected package. Rotate any credentials that were present there and create a fresh local `backend/.env` from the example file.
