from app.tools.academic_tools import get_attendance, get_marks


class AcademicAgent:

    def process(self, message):

        try:
            msg = message.lower()

            if "attendance" in msg:
                return get_attendance()

            elif "marks" in msg:
                return get_marks()

            else:
                return {
                    "message": "Academic information not found"
                }

        except Exception as e:
            return {
                "error": str(e)
            }