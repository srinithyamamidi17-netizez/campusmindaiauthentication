from app.api.attendance import get_attendance

def handle():
    return get_attendance()