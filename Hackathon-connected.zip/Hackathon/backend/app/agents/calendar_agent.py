from app.tools.calendar_tools import get_calendar


class CalendarAgent:

    def process(self, message):

        try:
            data = get_calendar()

            return {
                "message": message,
                "calendar": data
            }

        except Exception as e:
            return {
                "error": str(e)
            }