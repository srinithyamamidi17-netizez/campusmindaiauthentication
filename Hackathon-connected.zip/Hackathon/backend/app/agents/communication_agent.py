from app.tools.communication_tools import send_announcement


class CommunicationAgent:

    def process(self, message):

        try:
            response = send_announcement(message)

            return {
                "message": message,
                "communication": response
            }

        except Exception as e:
            return {
                "error": str(e)
            }