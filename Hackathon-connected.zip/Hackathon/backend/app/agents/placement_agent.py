#from tools.placement_tools import get_placements
from app.tools.placement_tools import get_placements


class PlacementAgent:

    def process(self, message):

        try:
            data = get_placements()

            return {
                "message": message,
                "placements": data
            }

        except Exception as e:
            return {
                "error": str(e)
            }