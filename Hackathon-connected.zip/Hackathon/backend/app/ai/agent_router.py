from app.ai.orchestrator import route_query

from app.api.attendance import get_attendance
from app.api.events import get_events
from app.api.notifications import get_notifications

from app.agents.academic_agent import AcademicAgent
from app.agents.placement_agent import PlacementAgent
from app.agents.calendar_agent import CalendarAgent
from app.agents.communication_agent import CommunicationAgent


# Initialize agents
academic_agent = AcademicAgent()
placement_agent = PlacementAgent()
calendar_agent = CalendarAgent()
communication_agent = CommunicationAgent()


def process_query(message):

    agent = route_query(message)

    print("=" * 40)
    print("Incoming Query:", message)
    print("Selected Agent:", agent)
    print("=" * 40)


    # Attendance Agent
    if agent == "attendance":
        return {
            "agent": "Attendance Agent",
            "response": get_attendance()
        }


    # Academic Agent
    elif agent == "academic":
        return {
            "agent": "Academic Agent",
            "response": academic_agent.process(message)
        }


    # Placement Agent
    elif agent == "placement":
        return {
            "agent": "Placement Agent",
            "response": placement_agent.process(message)
        }


    # Calendar Agent
    elif agent == "calendar":
        return {
            "agent": "Calendar Agent",
            "response": calendar_agent.process(message)
        }


    # Events Agent
    elif agent == "events":
        return {
            "agent": "Events Agent",
            "response": get_events()
        }


    # Notification Agent
    elif agent == "notifications":
        return {
            "agent": "Notification Agent",
            "response": get_notifications()
        }


    # Communication Agent
    elif agent == "communication":
      return {
        "agent": "Communication Agent",
        "response": communication_agent.process(message)
     }


    # Default Chat Agent
    else:
        return {
            "agent": "Chat Agent",
            "response": "I can help you with campus-related queries."
        }