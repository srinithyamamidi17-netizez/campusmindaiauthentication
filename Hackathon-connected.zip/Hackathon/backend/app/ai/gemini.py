import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("gemini-2.5-pro")
def ask_gemini(prompt):
    response = model.generate_content(prompt)
    return response.text
def ask_gemini(prompt):
    return "Gemini integration coming soon."