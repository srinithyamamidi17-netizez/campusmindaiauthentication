def route_query(message):

    msg = message.lower()

    if "attendance" in msg or "present" in msg:
        return "attendance"

    elif "marks" in msg or "academic" in msg or "subject" in msg:
        return "academic"

    elif "placement" in msg or "job" in msg or "internship" in msg:
        return "placement"

    elif "calendar" in msg or "schedule" in msg or "timetable" in msg:
        return "calendar"

    elif "event" in msg or "fest" in msg:
        return "events"

    elif "notification" in msg or "notice" in msg:
        return "notifications"

    elif "message" in msg or "announcement" in msg or "communication" in msg:
        return "communication"

    # RAG / Knowledge Base
    elif (
        "rule" in msg
        or "policy" in msg
        or "regulation" in msg
        or "syllabus" in msg
        or "college" in msg
        or "document" in msg
        or "handbook" in msg
        or "guide" in msg
    ):
        return "knowledge"

    else:
        return "chat"