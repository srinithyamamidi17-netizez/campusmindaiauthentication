from fastapi import APIRouter

router = APIRouter(prefix="/attendance", tags=["Attendance"])

from fastapi import Depends
from app.auth.auth_utils import get_current_user

@router.get("/")
def get_attendance(user=Depends(get_current_user)):
    return {
        "student": "Student1",
        "attendance": "85%"
    }