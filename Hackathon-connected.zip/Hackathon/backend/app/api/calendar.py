from fastapi import APIRouter

router = APIRouter(prefix="/calendar", tags=["Calendar"])

@router.get("/")
def get_calendar():
    return {
        "today": "AI Hackathon Meeting - 2 PM"
    }