from fastapi import APIRouter
from pydantic import BaseModel
#from app.ai.agent_router import process_query

from app.ai.agent_router import process_query

router = APIRouter()

class ChatRequest(BaseModel):
    message: str

@router.post("/chat")
def chat(request: ChatRequest):
    return process_query(request.message)