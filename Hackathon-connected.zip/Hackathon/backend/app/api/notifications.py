from fastapi import APIRouter

router = APIRouter(prefix="/notifications", tags=["Notifications"])

@router.get("/")
def get_notifications():
    return {
        "notifications": [
            "Assignment due tomorrow",
            "Placement registration open"
        ]
    }