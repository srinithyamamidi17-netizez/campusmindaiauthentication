from fastapi import APIRouter, HTTPException

from app.database.db import users_collection
from app.models.schemas import RegisterRequest

router = APIRouter(
    prefix="/register",
    tags=["Registration"],
)


def _register(payload: RegisterRequest, role: str, label: str):
    existing_user = users_collection.find_one({"username": payload.username})

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Username already exists",
        )

    users_collection.insert_one({
        "username": payload.username,
        "password": payload.password,
        "role": role,
        "name": payload.name or payload.username,
    })

    return {
        "status": "success",
        "message": f"{label} registered successfully",
    }


@router.post("/student")
def register_student(payload: RegisterRequest):
    return _register(payload, "student", "Student")


@router.post("/faculty")
def register_faculty(payload: RegisterRequest):
    return _register(payload, "faculty", "Faculty")


@router.post("/admin")
def register_admin(payload: RegisterRequest):
    return _register(payload, "admin", "Admin")
