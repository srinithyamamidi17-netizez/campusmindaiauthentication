from fastapi import APIRouter
from app.database.mongodb import db

router = APIRouter()

@router.get("/test-db")
def test_db():
    try:
        collections = db.list_collection_names()

        return {
            "status": "MongoDB Atlas Connected",
            "database": db.name,
            "collections": collections
        }

    except Exception as e:
        return {
            "status": "Connection Failed",
            "error": str(e)
        }