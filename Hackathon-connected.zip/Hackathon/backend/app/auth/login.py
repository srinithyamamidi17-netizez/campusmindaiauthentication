from fastapi import APIRouter, HTTPException

from app.auth.jwt_handler import create_access_token
from app.database.db import users_collection
from app.models.schemas import AuthRequest, TokenResponse

router = APIRouter(
    prefix="/login",
    tags=["Authentication"],
)


def _login(username: str, password: str, role: str, label: str) -> TokenResponse:
    user = users_collection.find_one({
        "username": username,
        "password": password,
        "role": role,
    })

    if not user:
        raise HTTPException(
            status_code=401,
            detail=f"Invalid {label} Credentials",
        )

    token = create_access_token({
        "sub": username,
        "role": role,
    })

    return TokenResponse(
        status="success",
        message=f"{label} Login Successful",
        access_token=token,
        name=user.get('name') or username,
    )


@router.post("/student", response_model=TokenResponse)
def student_login(payload: AuthRequest):
    return _login(payload.username, payload.password, "student", "Student")


@router.post("/faculty", response_model=TokenResponse)
def faculty_login(payload: AuthRequest):
    return _login(payload.username, payload.password, "faculty", "Faculty")


@router.post("/admin", response_model=TokenResponse)
def admin_login(payload: AuthRequest):
    return _login(payload.username, payload.password, "admin", "Admin")
