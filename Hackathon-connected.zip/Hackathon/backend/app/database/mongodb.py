from app.database.db import db

students = db.students
faculty = db.faculty
attendance = db.attendance
calendar = db.calendar
events = db.events
internships = db.internships
notifications = db.notifications
