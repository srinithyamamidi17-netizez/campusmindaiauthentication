
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.auth.login import router as login_router
from app.api.register import router as register_router
from app.api.attendance import router as attendance_router
from app.api.calendar import router as calendar_router
from app.api.events import router as events_router
from app.api.notifications import router as notifications_router
from app.api.chat import router as chat_router
from app.api.test_db import router as database_router
from app.api.chat_ai import router as ai_router

app = FastAPI(
    title="Campus Mind AI Backend",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(login_router)
app.include_router(register_router)
app.include_router(attendance_router)
app.include_router(calendar_router)
app.include_router(events_router)
app.include_router(notifications_router)
app.include_router(chat_router)
app.include_router(database_router)
app.include_router(ai_router)

@app.get("/")
def home():
    return {
        "status": "success",
        "message": "Campus Mind AI Backend is Running!"
    }