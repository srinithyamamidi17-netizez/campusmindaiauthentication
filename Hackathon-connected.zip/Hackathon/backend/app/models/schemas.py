from pydantic import BaseModel, Field


class AuthRequest(BaseModel):
    username: str = Field(..., min_length=1)
    password: str = Field(..., min_length=6)


class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=1)
    password: str = Field(..., min_length=6)
    name: str | None = None


class TokenResponse(BaseModel):
    status: str
    message: str
    access_token: str
    name: str
    token_type: str = "bearer"


class ChatMessageRequest(BaseModel):
    message: str = Field(..., min_length=1)


class AIChatRequest(BaseModel):
    question: str = Field(..., min_length=1)


class ProfileUpdateRequest(BaseModel):
    name: str | None = None


class MemoryMessageRequest(BaseModel):
    message: str = Field(..., min_length=1)
