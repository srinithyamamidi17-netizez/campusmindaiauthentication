from pathlib import Path

from langchain_chroma import Chroma
from langchain_ollama import OllamaEmbeddings, OllamaLLM


BASE_DIR = Path(__file__).resolve().parents[1]
CHROMA_DIR = BASE_DIR / "chroma_db"


embeddings = OllamaEmbeddings(
    model="nomic-embed-text"
)

db = Chroma(
    persist_directory=str(CHROMA_DIR),
    embedding_function=embeddings
)

retriever = db.as_retriever(
    search_kwargs={"k": 3}
)

llm = OllamaLLM(
    model="llama3"
)


def ask_question(question: str) -> str:

    documents = retriever.invoke(question)

    context = "\n\n".join(
        document.page_content
        for document in documents
    )

    prompt = f"""
You are CampusMind AI, a helpful college assistant.

Answer the user's question using the provided campus information.

If the answer is not present in the context, say that the information
is not available in the campus knowledge base.

Context:
{context}

Question:
{question}

Answer:
"""

    return llm.invoke(prompt)