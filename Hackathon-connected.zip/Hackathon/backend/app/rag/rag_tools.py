from app.rag.knowledge_agent import retriever

def search_knowledge(query):

    docs = retriever.invoke(query)

    result = []

    for doc in docs:
        result.append(doc.page_content)

    return result