def get_attendance():
    return {
        "agent": "Academic Agent",
        "attendance": "95%"
    }


def get_marks():
    return {
        "agent": "Academic Agent",
        "marks": {
            "DBMS": 92,
            "Machine Learning": 95,
            "DAA": 89
        }
    }