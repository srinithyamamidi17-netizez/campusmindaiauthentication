def get_calendar():
    return {
        "events": [
            {
                "title": "Project Review",
                "date": "2026-08-10"
            },
            {
                "title": "Hackathon",
                "date": "2026-08-15"
            }
        ]
    }