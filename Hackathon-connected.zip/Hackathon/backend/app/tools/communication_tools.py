def send_announcement(message):

    return {
        "status": "success",
        "announcement": message,
        "sent_to": "Students"
    }