def get_placements():
    return {
        "agent": "Placement Agent",
        "companies": [
            "Google",
            "Microsoft",
            "Amazon",
            "Infosys"
        ]
    }