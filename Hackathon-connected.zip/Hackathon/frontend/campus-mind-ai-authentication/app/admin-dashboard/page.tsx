'use client'

import {
  Activity,
  Bell,
  Bot,
  LockKeyhole,
  Settings2,
  Users,
} from 'lucide-react'
import { DashboardBody } from '@/components/dashboard/DashboardBody'
import { DashboardShell } from '@/components/dashboard/DashboardShell'

export default function AdminDashboardPage() {
  return (
    <DashboardShell role="admin">
      {(user) => (
        <DashboardBody
          user={user}
          greetingRole="Administrator Dashboard"
          stats={[
            { label: 'Total Users', value: '4,812', hint: '+124 this month', icon: Users },
            { label: 'Active Agents', value: '12', hint: 'All operational', icon: Bot },
            { label: 'System Uptime', value: '99.9%', hint: 'Last 90 days', icon: Activity },
            { label: 'Open Alerts', value: '2', hint: 'Needs review', icon: Bell },
          ]}
          agentsHeading="Platform Controls"
          agents={[
            {
              title: 'Agent Orchestrator',
              description:
                'Monitor, deploy, and configure every campus AI agent from a single control plane.',
              icon: Bot,
              status: 'Healthy',
            },
            {
              title: 'User & Role Management',
              description:
                'Provision accounts, assign roles, and manage granular permissions across the campus.',
              icon: LockKeyhole,
              status: 'Active',
            },
            {
              title: 'System Configuration',
              description:
                'Tune integrations, security policies, and platform-wide settings with audit logging.',
              icon: Settings2,
              status: 'Online',
            },
          ]}
        />
      )}
    </DashboardShell>
  )
}
