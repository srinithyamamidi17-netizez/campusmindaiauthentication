import { ShieldCheck } from 'lucide-react'
import { AuthPageLayout } from '@/components/auth/AuthPageLayout'

export default function AdminLoginPage() {
  return (
    <AuthPageLayout
      role="admin"
      icon={ShieldCheck}
      highlights={[
        'Monitor all campus AI agents',
        'Manage users, roles & permissions',
        'System health & security oversight',
      ]}
    />
  )
}
