'use client'

import { useEffect, useState } from 'react'
import {
  BookOpen,
  Bot,
  CalendarDays,
  ChartLine,
  GraduationCap,
  MessageSquareText,
} from 'lucide-react'
import { DashboardBody, type StatItem } from '@/components/dashboard/DashboardBody'
import { DashboardShell } from '@/components/dashboard/DashboardShell'
import { apiFetch } from '@/lib/api'

interface AttendanceResponse {
  student: string
  attendance: string
}

export default function StudentDashboardPage() {
  const [stats, setStats] = useState<StatItem[]>([
    { label: 'Classes Today', value: '—', hint: 'Loading from backend', icon: CalendarDays },
    { label: 'Attendance', value: '—', hint: 'Loading from backend', icon: ChartLine },
    { label: 'Current GPA', value: '—', hint: 'Not available yet', icon: GraduationCap },
    { label: 'Assignments Due', value: '—', hint: 'Not available yet', icon: BookOpen },
  ])

  useEffect(() => {
    let cancelled = false

    async function loadDashboard() {
      try {
        const attendance = await apiFetch<AttendanceResponse>('/attendance/')
        if (cancelled) return
        setStats((current) => current.map((item) =>
          item.label === 'Attendance'
            ? { ...item, value: attendance.attendance, hint: `Backend data for ${attendance.student}` }
            : item,
        ))
      } catch {
        // Keep the dashboard usable if an optional dashboard request fails.
      }
    }

    loadDashboard()
    return () => { cancelled = true }
  }, [])

  return (
    <DashboardShell role="student">
      {(user) => (
        <DashboardBody
          user={user}
          greetingRole="Student Dashboard"
          stats={stats}
          agentsHeading="Your AI Agents"
          agents={[
            {
              title: 'AI Study Tutor',
              description:
                'Get instant explanations, practice problems, and personalized study plans across your subjects.',
              icon: Bot,
              status: 'Online',
            },
            {
              title: 'Schedule Assistant',
              description:
                'Smart reminders for classes, exams, and deadlines synced with your timetable.',
              icon: CalendarDays,
              status: 'Active',
            },
            {
              title: 'Campus Q&A',
              description:
                'Ask anything about facilities, events, fees, or library resources in natural language.',
              icon: MessageSquareText,
              status: 'Online',
            },
          ]}
        />
      )}
    </DashboardShell>
  )
}
