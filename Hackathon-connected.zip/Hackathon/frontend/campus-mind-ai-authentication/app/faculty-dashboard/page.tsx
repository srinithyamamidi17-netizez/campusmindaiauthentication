'use client'

import {
  Bot,
  CalendarDays,
  ChartLine,
  MessageSquareText,
  Users,
} from 'lucide-react'
import { DashboardBody } from '@/components/dashboard/DashboardBody'
import { DashboardShell } from '@/components/dashboard/DashboardShell'

export default function FacultyDashboardPage() {
  return (
    <DashboardShell role="faculty">
      {(user) => (
        <DashboardBody
          user={user}
          greetingRole="Faculty Dashboard"
          stats={[
            { label: 'Active Courses', value: '5', hint: 'This semester', icon: CalendarDays },
            { label: 'Total Students', value: '218', hint: 'Across sections', icon: Users },
            { label: 'Avg. Attendance', value: '88%', hint: 'Last 30 days', icon: ChartLine },
            { label: 'Pending Grading', value: '27', hint: 'Submissions', icon: MessageSquareText },
          ]}
          agentsHeading="Teaching AI Agents"
          agents={[
            {
              title: 'AI Teaching Assistant',
              description:
                'Draft lecture material, quizzes, and rubrics, then auto-grade objective assessments.',
              icon: Bot,
              status: 'Online',
            },
            {
              title: 'Attendance Agent',
              description:
                'Automated attendance tracking with anomaly alerts and weekly summaries.',
              icon: Users,
              status: 'Active',
            },
            {
              title: 'Performance Insights',
              description:
                'Identify at-risk students early with predictive analytics and engagement trends.',
              icon: ChartLine,
              status: 'Online',
            },
          ]}
        />
      )}
    </DashboardShell>
  )
}
