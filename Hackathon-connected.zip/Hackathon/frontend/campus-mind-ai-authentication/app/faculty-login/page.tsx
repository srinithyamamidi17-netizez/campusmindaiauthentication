import { BookOpen } from 'lucide-react'
import { AuthPageLayout } from '@/components/auth/AuthPageLayout'

export default function FacultyLoginPage() {
  return (
    <AuthPageLayout
      role="faculty"
      icon={BookOpen}
      highlights={[
        'Manage courses, grades & attendance',
        'AI teaching assistant for content prep',
        'Real-time student performance insights',
      ]}
    />
  )
}
