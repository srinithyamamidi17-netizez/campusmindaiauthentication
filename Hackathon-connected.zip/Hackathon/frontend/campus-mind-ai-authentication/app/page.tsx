import { Sparkles } from 'lucide-react'
import { AnimatedBackground } from '@/components/animated-background'
import { RoleSelector } from '@/components/auth/RoleSelector'
import { Logo } from '@/components/logo'
import { SiteFooter } from '@/components/site-footer'
import { ThemeToggle } from '@/components/theme-toggle'

export default function LandingPage() {
  return (
    <div className="flex min-h-svh flex-col">
      <AnimatedBackground />

      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
        <Logo />
        <ThemeToggle />
      </header>

      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col items-center justify-center px-6 py-10">
        <div className="flex flex-col items-center gap-6 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-card/60 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur">
            <Sparkles className="size-3.5 text-primary" />
            Multi-Agent AI for the modern campus
          </span>

          <h1 className="font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl md:text-6xl">
            Welcome to{' '}
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              CampusMind AI
            </span>
          </h1>

          <p className="max-w-xl text-base leading-relaxed text-muted-foreground text-pretty sm:text-lg">
            Your AI-powered Smart Campus Assistant. Choose your role to sign in
            and access personalized dashboards, intelligent agents, and campus
            services.
          </p>
        </div>

        <section className="mt-12 w-full" aria-label="Select your role to sign in">
          <RoleSelector />
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
