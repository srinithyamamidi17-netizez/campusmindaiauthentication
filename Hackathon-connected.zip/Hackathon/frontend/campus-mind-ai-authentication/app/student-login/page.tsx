import { GraduationCap } from 'lucide-react'
import { AuthPageLayout } from '@/components/auth/AuthPageLayout'

export default function StudentLoginPage() {
  return (
    <AuthPageLayout
      role="student"
      icon={GraduationCap}
      illustration="/student-illustration.png"
      highlights={[
        'Personalized class schedule & reminders',
        '24/7 AI tutoring and study help',
        'Instant access to grades & attendance',
      ]}
    />
  )
}
