export function AnimatedBackground() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background to-secondary/40" />
      <div className="animate-float-slow absolute -left-24 -top-24 size-[28rem] rounded-full bg-primary/25 blur-[110px]" />
      <div
        className="animate-float-slow absolute -right-24 top-1/3 size-[26rem] rounded-full bg-accent/25 blur-[120px]"
        style={{ animationDelay: '2.5s' }}
      />
      <div
        className="animate-float-slow absolute bottom-[-6rem] left-1/3 size-[24rem] rounded-full bg-chart-3/20 blur-[120px]"
        style={{ animationDelay: '5s' }}
      />
      {/* Subtle grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.04] dark:opacity-[0.06]"
        style={{
          backgroundImage:
            'linear-gradient(to right, currentColor 1px, transparent 1px), linear-gradient(to bottom, currentColor 1px, transparent 1px)',
          backgroundSize: '44px 44px',
        }}
      />
    </div>
  )
}
