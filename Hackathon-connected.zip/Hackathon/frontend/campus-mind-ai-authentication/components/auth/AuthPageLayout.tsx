import { ArrowLeft, type LucideIcon } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { LoginForm } from '@/components/auth/LoginForm'
import { AnimatedBackground } from '@/components/animated-background'
import { Logo } from '@/components/logo'
import { ThemeToggle } from '@/components/theme-toggle'
import { ROLES, type Role } from '@/lib/auth'

interface AuthPageLayoutProps {
  role: Role
  icon: LucideIcon
  highlights: string[]
  /** Optional illustration shown on the branding panel */
  illustration?: string
}

export function AuthPageLayout({
  role,
  icon: Icon,
  highlights,
  illustration,
}: AuthPageLayoutProps) {
  const config = ROLES[role]

  return (
    <div className="flex min-h-svh flex-col">
      <AnimatedBackground />

      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
        <Link href="/" aria-label="CampusMind AI home">
          <Logo />
        </Link>
        <ThemeToggle />
      </header>

      <main className="mx-auto flex w-full max-w-5xl flex-1 items-center px-6 py-8">
        <div className="glass-card animate-in fade-in zoom-in-95 duration-500 grid w-full overflow-hidden rounded-3xl shadow-2xl shadow-primary/10 lg:grid-cols-2">
          {/* Branding / illustration panel */}
          <div className="relative hidden flex-col justify-between gap-8 bg-gradient-to-br from-primary via-primary to-accent p-10 text-primary-foreground lg:flex">
            <div
              aria-hidden="true"
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage:
                  'radial-gradient(circle at 20% 20%, white 1px, transparent 1.5px)',
                backgroundSize: '26px 26px',
              }}
            />
            <div className="relative flex items-center gap-2.5">
              <span className="grid size-10 place-items-center rounded-xl bg-white/15 backdrop-blur">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <span className="font-display text-lg font-bold">
                {config.shortTitle} Portal
              </span>
            </div>

            {illustration && (
              <div className="relative flex items-center justify-center">
                <Image
                  src={illustration || '/placeholder.svg'}
                  alt=""
                  width={340}
                  height={340}
                  className="h-auto w-full max-w-[300px] drop-shadow-2xl"
                  priority
                />
              </div>
            )}

            <div className="relative flex flex-col gap-3">
              <p className="font-display text-2xl font-bold text-balance leading-tight">
                Your AI-powered Smart Campus Assistant
              </p>
              <ul className="flex flex-col gap-2 text-sm text-primary-foreground/85">
                {highlights.map((item) => (
                  <li key={item} className="flex items-center gap-2">
                    <span className="size-1.5 rounded-full bg-primary-foreground/70" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Form panel */}
          <div className="flex flex-col justify-center gap-6 bg-card/40 p-8 backdrop-blur-xl sm:p-10">
            <div className="flex flex-col gap-2">
              <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-lg shadow-primary/30 lg:hidden">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <h1 className="font-display text-2xl font-bold tracking-tight">
                {config.title}
              </h1>
              <p className="text-sm text-muted-foreground text-pretty">
                {config.description}
              </p>
            </div>

            <LoginForm role={role} />

            <Link
              href="/"
              className="inline-flex items-center justify-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft className="size-4" />
              Back to Home
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
