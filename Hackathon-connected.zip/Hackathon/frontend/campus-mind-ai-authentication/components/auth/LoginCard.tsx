import { ArrowRight, type LucideIcon } from 'lucide-react'
import Link from 'next/link'
import type { RoleConfig } from '@/lib/auth'

interface LoginCardProps {
  config: RoleConfig
  icon: LucideIcon
  /** stagger delay in ms for the entrance animation */
  delay?: number
}

export function LoginCard({ config, icon: Icon, delay = 0 }: LoginCardProps) {
  return (
    <Link
      href={config.loginPath}
      style={{ animationDelay: `${delay}ms` }}
      className="glass-card group animate-in fade-in slide-in-from-bottom-4 fill-mode-both flex flex-col gap-4 rounded-2xl p-6 shadow-xl shadow-primary/5 outline-none transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-primary/15 hover:ring-1 hover:ring-primary/40 focus-visible:ring-2 focus-visible:ring-primary"
    >
      <span className="grid size-12 place-items-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-lg shadow-primary/30 transition-transform duration-300 group-hover:scale-105">
        <Icon className="size-6" aria-hidden="true" />
      </span>

      <div className="flex flex-col gap-1.5">
        <h2 className="font-display text-xl font-bold tracking-tight">
          {config.title}
        </h2>
        <p className="text-sm leading-relaxed text-muted-foreground text-pretty">
          {config.description}
        </p>
      </div>

      <span className="mt-1 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
        Continue
        <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
      </span>
    </Link>
  )
}
