'use client'

import { LoaderCircle } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { toast } from 'sonner'
import { PasswordInput } from '@/components/auth/PasswordInput'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ROLES, saveSession, type Role } from '@/lib/auth'
import { loginApi, saveToken } from '@/lib/api'

interface LoginFormProps {
  role: Role
  /** Whether to render the "Remember me" checkbox (all roles use it here) */
  showRemember?: boolean
}

interface FieldErrors {
  identifier?: string
  password?: string
}

export function LoginForm({ role, showRemember = true }: LoginFormProps) {
  const config = ROLES[role]
  const router = useRouter()

  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [remember, setRemember] = useState(false)
  const [errors, setErrors] = useState<FieldErrors>({})
  const [loading, setLoading] = useState(false)

  function validate(): boolean {
    const next: FieldErrors = {}
    if (!identifier.trim()) {
      next.identifier = `${config.identifierLabel} is required.`
    }
    if (!password) {
      next.password = 'Password is required.'
    } else if (password.length < 6) {
      next.password = 'Password must be at least 6 characters.'
    }
    setErrors(next)
    return Object.keys(next).length === 0
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (loading) return
    if (!validate()) return

    setLoading(true)
    try {
      const result = await loginApi(role, identifier.trim(), password)
      const user = {
        role,
        name: result.name || identifier.trim(),
        identifier: identifier.trim(),
      } as const
      saveToken(result.access_token, remember)
      saveSession(user, remember)
      toast.success(`Welcome back, ${user.name}!`, {
        description: 'Redirecting to your dashboard…',
      })
      router.push(config.dashboardPath)
    } catch (err) {
      const code = err instanceof Error ? err.message : 'INVALID'
      if (code === 'Failed to fetch' || code === 'NetworkError') {
        toast.error('Network error', {
          description: 'Could not reach the backend at ' + (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000') + '.',
        })
      } else if (code === 'NETWORK') {
        toast.error('Network error', {
          description: 'We could not reach the server. Please try again.',
        })
      } else {
        toast.error('Invalid credentials', {
          description: `Check your ${config.identifierLabel.toLowerCase()} and password, then try again.`,
        })
      }
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5" noValidate>
      <div className="flex flex-col gap-2">
        <Label htmlFor="identifier">{config.identifierLabel}</Label>
        <Input
          id="identifier"
          name="identifier"
          className="h-11"
          autoComplete="username"
          placeholder={config.identifierPlaceholder}
          value={identifier}
          disabled={loading}
          aria-invalid={!!errors.identifier}
          onChange={(e) => {
            setIdentifier(e.target.value)
            if (errors.identifier)
              setErrors((p) => ({ ...p, identifier: undefined }))
          }}
        />
        {errors.identifier && (
          <p className="text-xs text-destructive">{errors.identifier}</p>
        )}
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="password">Password</Label>
          <Link
            href="#"
            className="text-xs font-medium text-primary hover:underline"
            onClick={(e) => {
              e.preventDefault()
              toast.info('Password reset', {
                description: 'A reset link would be sent to your registered email.',
              })
            }}
          >
            Forgot password?
          </Link>
        </div>
        <PasswordInput
          id="password"
          name="password"
          className="h-11"
          autoComplete="current-password"
          placeholder="Enter your password"
          value={password}
          disabled={loading}
          aria-invalid={!!errors.password}
          onChange={(e) => {
            setPassword(e.target.value)
            if (errors.password)
              setErrors((p) => ({ ...p, password: undefined }))
          }}
        />
        {errors.password && (
          <p className="text-xs text-destructive">{errors.password}</p>
        )}
      </div>

      {showRemember && (
        <Label
          htmlFor="remember"
          className="w-fit cursor-pointer text-sm font-normal text-muted-foreground"
        >
          <Checkbox
            id="remember"
            checked={remember}
            onCheckedChange={(checked) => setRemember(checked === true)}
            disabled={loading}
          />
          Remember me on this device
        </Label>
      )}

      <Button
        type="submit"
        disabled={loading}
        className="h-11 w-full bg-gradient-to-r from-primary to-accent text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-opacity hover:opacity-90"
      >
        {loading ? (
          <>
            <LoaderCircle className="size-4 animate-spin" />
            Signing in…
          </>
        ) : (
          `Sign in as ${config.shortTitle}`
        )}
      </Button>

      <div className="rounded-lg border border-dashed border-border bg-muted/40 px-3 py-2 text-center text-xs text-muted-foreground">
        Demo credentials — {config.identifierLabel}:{' '}
        <span className="font-medium text-foreground">
          {config.demo.identifier}
        </span>{' '}
        · Password:{' '}
        <span className="font-medium text-foreground">
          {config.demo.password}
        </span>
      </div>
    </form>
  )
}
