'use client'

import { LoaderCircle } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { getSession, ROLES, type AuthUser, type Role } from '@/lib/auth'

interface ProtectedRouteProps {
  role: Role
  children: (user: AuthUser) => React.ReactNode
}

/**
 * Client-side route guard. Reads the mock session from storage and redirects
 * unauthenticated users to the matching login page. If a user is signed in
 * with a different role, they are sent to their own dashboard.
 */
export function ProtectedRoute({ role, children }: ProtectedRouteProps) {
  const router = useRouter()
  const [user, setUser] = useState<AuthUser | null>(null)
  const [status, setStatus] = useState<'checking' | 'authorized'>('checking')

  useEffect(() => {
    const session = getSession()
    if (!session) {
      router.replace(ROLES[role].loginPath)
      return
    }
    if (session.role !== role) {
      router.replace(ROLES[session.role].dashboardPath)
      return
    }
    setUser(session)
    setStatus('authorized')
  }, [role, router])

  if (status === 'checking' || !user) {
    return (
      <div className="flex min-h-svh flex-col items-center justify-center gap-3 text-muted-foreground">
        <LoaderCircle className="size-6 animate-spin text-primary" />
        <p className="text-sm">Verifying your session…</p>
      </div>
    )
  }

  return <>{children(user)}</>
}
