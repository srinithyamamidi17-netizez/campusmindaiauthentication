import { BookOpen, GraduationCap, ShieldCheck } from 'lucide-react'
import { LoginCard } from '@/components/auth/LoginCard'
import { ROLES } from '@/lib/auth'

export function RoleSelector() {
  return (
    <div className="grid w-full gap-5 sm:grid-cols-2 lg:grid-cols-3">
      <LoginCard config={ROLES.student} icon={GraduationCap} delay={0} />
      <LoginCard config={ROLES.faculty} icon={BookOpen} delay={120} />
      <LoginCard config={ROLES.admin} icon={ShieldCheck} delay={240} />
    </div>
  )
}
