import type { LucideIcon } from 'lucide-react'
import { Card } from '@/components/ui/card'
import type { AuthUser } from '@/lib/auth'

export interface StatItem {
  label: string
  value: string
  hint: string
  icon: LucideIcon
}

export interface AgentItem {
  title: string
  description: string
  icon: LucideIcon
  status: string
}

interface DashboardBodyProps {
  user: AuthUser
  greetingRole: string
  stats: StatItem[]
  agentsHeading: string
  agents: AgentItem[]
}

export function DashboardBody({
  user,
  greetingRole,
  stats,
  agentsHeading,
  agents,
}: DashboardBodyProps) {
  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-1">
        <p className="text-sm font-medium text-primary">{greetingRole}</p>
        <h1 className="font-display text-3xl font-bold tracking-tight text-balance">
          Welcome back, {user.name.split(' ')[0]}
        </h1>
        <p className="text-sm text-muted-foreground text-pretty">
          Here&apos;s what your campus AI agents have prepared for you today.
        </p>
      </div>

      <section aria-label="Overview" className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card
            key={stat.label}
            className="gap-3 rounded-2xl bg-card/60 p-5 ring-1 ring-border/60 backdrop-blur"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{stat.label}</span>
              <span className="grid size-9 place-items-center rounded-lg bg-primary/10 text-primary">
                <stat.icon className="size-4" />
              </span>
            </div>
            <p className="font-display text-2xl font-bold">{stat.value}</p>
            <p className="text-xs text-muted-foreground">{stat.hint}</p>
          </Card>
        ))}
      </section>

      <section aria-label={agentsHeading} className="flex flex-col gap-4">
        <h2 className="font-display text-lg font-bold tracking-tight">
          {agentsHeading}
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {agents.map((agent) => (
            <Card
              key={agent.title}
              className="group gap-3 rounded-2xl bg-card/60 p-5 ring-1 ring-border/60 backdrop-blur transition-all hover:-translate-y-1 hover:ring-primary/40"
            >
              <div className="flex items-center justify-between">
                <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-md shadow-primary/25">
                  <agent.icon className="size-5" />
                </span>
                <span className="rounded-full bg-primary/10 px-2.5 py-1 text-[0.7rem] font-medium text-primary">
                  {agent.status}
                </span>
              </div>
              <h3 className="font-display text-base font-semibold">
                {agent.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground text-pretty">
                {agent.description}
              </p>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
