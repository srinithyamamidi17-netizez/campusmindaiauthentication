'use client'

import { LogOut } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { ProtectedRoute } from '@/components/auth/ProtectedRoute'
import { AnimatedBackground } from '@/components/animated-background'
import { Logo } from '@/components/logo'
import { ThemeToggle } from '@/components/theme-toggle'
import { Button } from '@/components/ui/button'
import { clearSession, ROLES, type AuthUser, type Role } from '@/lib/auth'

interface DashboardShellProps {
  role: Role
  children: (user: AuthUser) => React.ReactNode
}

export function DashboardShell({ role, children }: DashboardShellProps) {
  const router = useRouter()

  function handleLogout() {
    clearSession()
    toast.success('Signed out', {
      description: 'You have been logged out successfully.',
    })
    router.replace('/')
  }

  return (
    <ProtectedRoute role={role}>
      {(user) => (
        <div className="flex min-h-svh flex-col">
          <AnimatedBackground />

          <header className="sticky top-0 z-20 border-b border-border/60 bg-background/70 backdrop-blur-xl">
            <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-6 py-3.5">
              <Logo />
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="hidden text-right sm:block">
                  <p className="text-sm font-semibold leading-tight">
                    {user.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {ROLES[role].shortTitle} · {user.identifier}
                  </p>
                </div>
                <ThemeToggle />
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 gap-1.5"
                  onClick={handleLogout}
                >
                  <LogOut className="size-4" />
                  <span className="hidden sm:inline">Logout</span>
                </Button>
              </div>
            </div>
          </header>

          <main className="mx-auto w-full max-w-6xl flex-1 px-6 py-8">
            {children(user)}
          </main>
        </div>
      )}
    </ProtectedRoute>
  )
}
