import { Brain } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Logo({
  className,
  showText = true,
}: {
  className?: string
  showText?: boolean
}) {
  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <span className="relative grid size-9 place-items-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-lg shadow-primary/30">
        <Brain className="size-5" aria-hidden="true" />
      </span>
      {showText && (
        <span className="font-display text-lg font-bold tracking-tight">
          CampusMind<span className="text-primary"> AI</span>
        </span>
      )}
    </div>
  )
}
