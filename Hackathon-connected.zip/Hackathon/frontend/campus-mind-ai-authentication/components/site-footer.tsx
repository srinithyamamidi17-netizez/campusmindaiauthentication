export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border/60 py-6">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-6 text-center text-xs text-muted-foreground sm:flex-row sm:text-left">
        <p>
          &copy; {new Date().getFullYear()} CampusMind AI. Smart Campus
          Multi-Agent Platform.
        </p>
        <p className="flex items-center gap-4">
          <span className="transition-colors hover:text-foreground">Privacy</span>
          <span className="transition-colors hover:text-foreground">Terms</span>
          <span className="transition-colors hover:text-foreground">Support</span>
        </p>
      </div>
    </footer>
  )
}
