const API_URL = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000').replace(/\/$/, '')

export interface LoginResponse {
  status: string
  message: string
  access_token: string
  token_type: string
  name: string
}

export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = typeof window !== 'undefined'
    ? window.localStorage.getItem('campusmind_token') ?? window.sessionStorage.getItem('campusmind_token')
    : null

  const headers = new Headers(options.headers)
  if (!headers.has('Content-Type') && options.body) headers.set('Content-Type', 'application/json')
  if (token) headers.set('Authorization', `Bearer ${token}`)

  const response = await fetch(`${API_URL}${path}`, { ...options, headers })
  const data = await response.json().catch(() => null)

  if (!response.ok) {
    const detail = data?.detail || data?.message || 'Request failed'
    throw new Error(detail)
  }

  return data as T
}

export async function loginApi(
  role: 'student' | 'faculty' | 'admin',
  username: string,
  password: string,
): Promise<LoginResponse> {
  return apiFetch<LoginResponse>(`/login/${role}`, {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  })
}

export function saveToken(token: string, remember: boolean) {
  if (typeof window === 'undefined') return
  const store = remember ? window.localStorage : window.sessionStorage
  const other = remember ? window.sessionStorage : window.localStorage
  store.setItem('campusmind_token', token)
  other.removeItem('campusmind_token')
}

export function clearToken() {
  if (typeof window === 'undefined') return
  window.localStorage.removeItem('campusmind_token')
  window.sessionStorage.removeItem('campusmind_token')
}
