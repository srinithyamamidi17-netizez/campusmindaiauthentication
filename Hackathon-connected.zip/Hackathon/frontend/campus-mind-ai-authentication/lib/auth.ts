export type Role = 'student' | 'faculty' | 'admin'

export interface AuthUser {
  role: Role
  name: string
  identifier: string
}

export interface RoleConfig {
  role: Role
  title: string
  shortTitle: string
  description: string
  /** Label for the identifier field, e.g. "Roll Number" */
  identifierLabel: string
  identifierPlaceholder: string
  loginPath: string
  dashboardPath: string
  /** Demo credentials surfaced on the login screen */
  demo: { identifier: string; password: string }
}

export const ROLES: Record<Role, RoleConfig> = {
  student: {
    role: 'student',
    title: 'Student Login',
    shortTitle: 'Student',
    description: 'Access schedules, AI tutoring, grades, and campus services.',
    identifierLabel: 'Roll Number',
    identifierPlaceholder: 'e.g. STU1001',
    loginPath: '/student-login',
    dashboardPath: '/dashboard',
    demo: { identifier: 'STU1001', password: 'student123' },
  },
  faculty: {
    role: 'faculty',
    title: 'Faculty Login',
    shortTitle: 'Faculty',
    description: 'Manage courses, attendance, and AI teaching assistants.',
    identifierLabel: 'Faculty ID',
    identifierPlaceholder: 'e.g. FAC2001',
    loginPath: '/faculty-login',
    dashboardPath: '/faculty-dashboard',
    demo: { identifier: 'FAC2001', password: 'faculty123' },
  },
  admin: {
    role: 'admin',
    title: 'Administrator Login',
    shortTitle: 'Administrator',
    description: 'Oversee campus agents, users, and system operations.',
    identifierLabel: 'Admin ID',
    identifierPlaceholder: 'e.g. ADM3001',
    loginPath: '/admin-login',
    dashboardPath: '/admin-dashboard',
    demo: { identifier: 'ADM3001', password: 'admin123' },
  },
}

const STORAGE_KEY = 'campusmind_auth'


export function saveSession(user: AuthUser, remember: boolean) {
  if (typeof window === 'undefined') return
  const store = remember ? window.localStorage : window.sessionStorage
  store.setItem(STORAGE_KEY, JSON.stringify(user))
  const other = remember ? window.sessionStorage : window.localStorage
  other.removeItem(STORAGE_KEY)
}

export function getSession(): AuthUser | null {
  if (typeof window === 'undefined') return null
  const raw =
    window.localStorage.getItem(STORAGE_KEY) ??
    window.sessionStorage.getItem(STORAGE_KEY)
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw) as AuthUser
    if (parsed && parsed.role && parsed.identifier) return parsed
    return null
  } catch {
    return null
  }
}

export function clearSession() {
  if (typeof window === 'undefined') return
  window.localStorage.removeItem(STORAGE_KEY)
  window.sessionStorage.removeItem(STORAGE_KEY)
  window.localStorage.removeItem('campusmind_token')
  window.sessionStorage.removeItem('campusmind_token')
}
